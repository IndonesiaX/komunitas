require 'compass'

# path from the library file to where you're keeping your compass stuff.
Compass::Frameworks.register("meyer-reset", :path => "#{File.dirname(__FILE__)}/..")

module MeyerReset

  VERSION = "2.0.1".freeze

end
